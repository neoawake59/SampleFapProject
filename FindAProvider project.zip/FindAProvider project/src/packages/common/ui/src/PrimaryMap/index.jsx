// PrimaryMap - SVG-based visual map showing provider pin locations
// Mirrors: src/packages/common/ui/src/PrimaryMap/index.jsx

import React, { useState } from 'react';
import { theme } from '../../../constants/src/index';
import { getAvatarColor } from '../../../utilities/src/index';

const s = {
  container: {
    width: '100%',
    height: '100%',
    background: '#e8eaed',
    borderRadius: theme.radii.lg,
    overflow: 'hidden',
    position: 'relative',
    minHeight: '400px',
  },
  svg: {
    width: '100%',
    height: '100%',
    display: 'block',
  },
  tooltip: {
    position: 'absolute',
    background: theme.colors.white,
    border: `1px solid ${theme.colors.gray200}`,
    borderRadius: theme.radii.md,
    padding: '10px 14px',
    boxShadow: theme.shadows.md,
    pointerEvents: 'none',
    zIndex: 10,
    maxWidth: '200px',
  },
  tooltipName: {
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.semibold,
    color: theme.colors.gray900,
    marginBottom: '2px',
  },
  tooltipSpecialty: {
    fontSize: theme.typography.sizes.xs,
    color: theme.colors.bupaBlue,
    marginBottom: '2px',
  },
  tooltipDistance: {
    fontSize: theme.typography.sizes.xs,
    color: theme.colors.gray500,
  },
  legend: {
    position: 'absolute',
    bottom: '16px',
    left: '16px',
    background: theme.colors.white,
    borderRadius: theme.radii.md,
    padding: '8px 12px',
    boxShadow: theme.shadows.sm,
    fontSize: theme.typography.sizes.xs,
    color: theme.colors.gray600,
  },
  zoomControls: {
    position: 'absolute',
    top: '16px',
    right: '16px',
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
  },
  zoomBtn: {
    width: '32px',
    height: '32px',
    background: theme.colors.white,
    border: `1px solid ${theme.colors.gray200}`,
    borderRadius: theme.radii.base,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    fontSize: '18px',
    fontWeight: 'bold',
    color: theme.colors.gray700,
    boxShadow: theme.shadows.sm,
    transition: theme.transitions.fast,
    lineHeight: 1,
  },
};

// Street grid paths - simulates a CBD suburb map
const STREET_GRID = [
  // Horizontal streets
  { d: 'M0,30 H100', name: 'Flinders Street' },
  { d: 'M0,42 H100', name: 'Collins Street' },
  { d: 'M0,50 H100', name: 'Bourke Street' },
  { d: 'M0,58 H100', name: 'Little Bourke Street' },
  { d: 'M0,66 H100', name: 'Lonsdale Street' },
  { d: 'M0,75 H100', name: '' },
  // Vertical streets
  { d: 'M20,0 V100', name: 'Spencer Street' },
  { d: 'M32,0 V100', name: 'King Street' },
  { d: 'M44,0 V100', name: 'William Street' },
  { d: 'M54,0 V100', name: 'Queen Street' },
  { d: 'M64,0 V100', name: 'Elizabeth Street' },
  { d: 'M74,0 V100', name: 'Swanston Street' },
  { d: 'M84,0 V100', name: 'Russell Street' },
];

// Landmark shapes
const LANDMARKS = [
  { x: 44, y: 15, w: 18, h: 6, label: 'Flagstaff\nGardens', fill: '#b7d4a0' },
  { x: 68, y: 60, w: 14, h: 14, label: 'Parliament', fill: '#d0c8b8' },
  { x: 22, y: 22, w: 20, h: 8, label: 'Southern\nCross', fill: '#c5c8ce' },
  { x: 22, y: 33, w: 12, h: 8, label: 'Flinders St\nStation', fill: '#d4c89a' },
  { x: 38, y: 20, w: 8, h: 10, label: 'Crown\nCasino', fill: '#c5c8ce' },
];

// User location dot
const UserDot = ({ cx, cy }) => (
  <g>
    <circle cx={cx} cy={cy} r="6" fill={theme.colors.bupaBlue} opacity="0.2" />
    <circle cx={cx} cy={cy} r="3.5" fill={theme.colors.bupaBlue} stroke="white" strokeWidth="1.5" />
  </g>
);

// Provider map pin
const MapPin = ({ provider, x, y, isActive, isHovered, onClick, onMouseEnter, onMouseLeave }) => {
  const pinColor = isActive ? theme.colors.bupaNavy : (isHovered ? theme.colors.bupaBlue : '#444');
  const scale = isActive || isHovered ? 1.3 : 1;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      style={{ transformOrigin: `${x}px ${y}px`, cursor: 'pointer', transition: 'transform 0.15s' }}
      onClick={() => onClick(provider)}
      onMouseEnter={() => onMouseEnter(provider)}
      onMouseLeave={onMouseLeave}
      role="button"
      aria-label={`${provider.name} - ${provider.typeLabel}`}
    >
      {/* Drop shadow */}
      <ellipse cx={0} cy={14} rx={5} ry={2} fill="rgba(0,0,0,0.15)" />
      {/* Pin body */}
      <path
        d="M0,-14 C-6,-14 -10,-10 -10,-5 C-10,3 0,14 0,14 C0,14 10,3 10,-5 C10,-10 6,-14 0,-14Z"
        fill={pinColor}
        stroke="white"
        strokeWidth="1.5"
      />
      {/* Pin inner dot */}
      <circle cx={0} cy={-5} r={3.5} fill="white" opacity="0.9" />
    </g>
  );
};

const PrimaryMap = ({ providers = [], activePin, onPinClick, onPinHover }) => {
  const [hoveredPin, setHoveredPin] = useState(null);
  const [tooltip, setTooltip] = useState(null);

  const handlePinMouseEnter = (provider, e) => {
    setHoveredPin(provider.id);
    if (onPinHover) onPinHover(provider.id);
    const rect = e.currentTarget.closest('svg').getBoundingClientRect();
    const svgEl = e.currentTarget;
    const bbox = svgEl.getBBox();
    // Tooltip near pin
    setTooltip({
      provider,
      x: (bbox.x / 100) * 100 + '%',
      top: `${(bbox.y / 100) * 100}%`,
    });
  };

  const handlePinMouseLeave = () => {
    setHoveredPin(null);
    if (onPinHover) onPinHover(null);
    setTooltip(null);
  };

  return (
    <div style={s.container}>
      <svg
        viewBox="0 0 100 100"
        style={s.svg}
        preserveAspectRatio="xMidYMid slice"
        aria-label="Map showing provider locations"
      >
        {/* Background tile */}
        <rect width="100" height="100" fill="#eef0f3" />

        {/* Water/river */}
        <path d="M0,20 Q25,18 50,22 Q75,26 100,20 L100,28 Q75,34 50,30 Q25,26 0,28Z" fill="#9FC8E8" opacity="0.5" />

        {/* Landmarks */}
        {LANDMARKS.map((lm, i) => (
          <g key={i}>
            <rect x={lm.x} y={lm.y} width={lm.w} height={lm.h} fill={lm.fill} rx="0.5" stroke="#b0b4bc" strokeWidth="0.3" />
          </g>
        ))}

        {/* Street grid */}
        {STREET_GRID.map((street, i) => (
          <path
            key={i}
            d={street.d}
            stroke="white"
            strokeWidth={street.name ? '1.2' : '0.6'}
            fill="none"
          />
        ))}

        {/* Street labels */}
        <text x="50" y="40.5" textAnchor="middle" fontSize="2.2" fill="#888" fontFamily="sans-serif">Collins St</text>
        <text x="50" y="48.5" textAnchor="middle" fontSize="2.2" fill="#888" fontFamily="sans-serif">Bourke St</text>
        <text x="50" y="64.5" textAnchor="middle" fontSize="2.2" fill="#888" fontFamily="sans-serif">Lonsdale St</text>
        <text x="73" y="80" textAnchor="middle" fontSize="2.2" fill="#888" fontFamily="sans-serif" transform="rotate(-90, 73, 60)">Swanston St</text>
        <text x="63" y="80" textAnchor="middle" fontSize="2.2" fill="#888" fontFamily="sans-serif" transform="rotate(-90, 63, 60)">Elizabeth St</text>

        {/* User location */}
        <UserDot cx={50} cy={50} />

        {/* Provider pins */}
        {providers.map((provider) => (
          <MapPin
            key={provider.id}
            provider={provider}
            x={provider.mapPosition.x}
            y={provider.mapPosition.y}
            isActive={activePin === provider.id}
            isHovered={hoveredPin === provider.id}
            onClick={onPinClick}
            onMouseEnter={(p) => {
              setHoveredPin(p.id);
              if (onPinHover) onPinHover(p.id);
              setTooltip({ provider: p });
            }}
            onMouseLeave={handlePinMouseLeave}
          />
        ))}
      </svg>

      {/* Tooltip */}
      {tooltip && (
        <div
          style={{
            ...s.tooltip,
            bottom: '80px',
            left: '50%',
            transform: 'translateX(-50%)',
          }}
        >
          <div style={s.tooltipName}>{tooltip.provider.name}</div>
          <div style={s.tooltipSpecialty}>{tooltip.provider.typeLabel}</div>
          <div style={s.tooltipDistance}>{tooltip.provider.distance} km away</div>
        </div>
      )}

      {/* Zoom controls (UI only) */}
      <div style={s.zoomControls}>
        <button style={s.zoomBtn} aria-label="Zoom in" title="Zoom in">+</button>
        <button style={s.zoomBtn} aria-label="Zoom out" title="Zoom out">−</button>
      </div>

      {/* Legend */}
      <div style={s.legend}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
          <svg width="10" height="10"><circle cx="5" cy="5" r="4" fill={theme.colors.bupaBlue} /></svg>
          Your location
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <svg width="10" height="14" viewBox="-5 -14 10 28">
            <path d="M0,-14 C-5,-14 -8,-10 -8,-5 C-8,2 0,12 0,12 C0,12 8,2 8,-5 C8,-10 5,-14 0,-14Z" fill="#444" />
          </svg>
          Provider
        </div>
      </div>
    </div>
  );
};

export default PrimaryMap;
