// ProviderCard - displays a single provider in search results
// Mirrors: src/packages/common/ui/src/ProviderCard/index.jsx

import React from 'react';
import { theme } from '../../../constants/src/index';
import { formatDistance, getInitials, getAvatarColor } from '../../../utilities/src/index';

const s = {
  card: {
    background: theme.colors.white,
    borderRadius: theme.radii.lg,
    border: `1px solid ${theme.colors.gray200}`,
    padding: '20px',
    cursor: 'pointer',
    transition: theme.transitions.fast,
    position: 'relative',
    overflow: 'hidden',
  },
  cardHovered: {
    borderColor: theme.colors.bupaBlue,
    boxShadow: theme.shadows.md,
    transform: 'translateY(-1px)',
  },
  cardActive: {
    borderColor: theme.colors.bupaBlue,
    boxShadow: `0 0 0 2px ${theme.colors.bupaBlue}, ${theme.shadows.md}`,
  },
  topRow: {
    display: 'flex',
    gap: '14px',
    alignItems: 'flex-start',
    marginBottom: '12px',
  },
  avatar: {
    width: '52px',
    height: '52px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: theme.typography.sizes.md,
    fontWeight: theme.typography.weights.bold,
    color: theme.colors.white,
    flexShrink: 0,
  },
  info: {
    flex: 1,
    minWidth: 0,
  },
  nameRow: {
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: '8px',
    marginBottom: '2px',
  },
  name: {
    fontSize: theme.typography.sizes.md,
    fontWeight: theme.typography.weights.semibold,
    color: theme.colors.gray900,
    lineHeight: theme.typography.lineHeights.tight,
  },
  distanceBadge: {
    fontSize: theme.typography.sizes.xs,
    fontWeight: theme.typography.weights.medium,
    color: theme.colors.gray500,
    background: theme.colors.gray100,
    borderRadius: theme.radii.full,
    padding: '2px 8px',
    whiteSpace: 'nowrap',
    flexShrink: 0,
  },
  specialty: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.bupaBlue,
    fontWeight: theme.typography.weights.medium,
    marginBottom: '2px',
  },
  practice: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.gray600,
    marginBottom: '2px',
  },
  address: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.gray500,
    display: 'flex',
    alignItems: 'flex-start',
    gap: '4px',
  },
  divider: {
    height: '1px',
    background: theme.colors.gray100,
    margin: '12px 0',
  },
  tagRow: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '6px',
    marginBottom: '12px',
  },
  tag: {
    fontSize: theme.typography.sizes.xs,
    fontWeight: theme.typography.weights.medium,
    borderRadius: theme.radii.full,
    padding: '3px 10px',
  },
  bottomRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '8px',
  },
  phoneLink: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.bupaBlue,
    fontWeight: theme.typography.weights.medium,
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    textDecoration: 'none',
  },
  ratingRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
  },
  ratingText: {
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.semibold,
    color: theme.colors.gray700,
  },
  reviewCount: {
    fontSize: theme.typography.sizes.xs,
    color: theme.colors.gray400,
  },
  bupaBadge: {
    position: 'absolute',
    top: '12px',
    right: '12px',
    fontSize: '10px',
    fontWeight: theme.typography.weights.bold,
    color: theme.colors.bupaNavy,
    background: theme.colors.bupaLightBlue,
    borderRadius: theme.radii.full,
    padding: '2px 8px',
    letterSpacing: '0.02em',
  },
};

const AcceptingTag = ({ accepting }) => (
  <span
    style={{
      ...s.tag,
      background: accepting ? '#E8F9F0' : '#FFF0F0',
      color: accepting ? theme.colors.bupaGreen : theme.colors.bupaRed,
    }}
  >
    {accepting ? '✓ Accepting patients' : '✗ Not accepting'}
  </span>
);

const OpenNowTag = ({ openNow }) => (
  <span
    style={{
      ...s.tag,
      background: openNow ? '#E8F9F0' : theme.colors.gray100,
      color: openNow ? theme.colors.bupaGreen : theme.colors.gray500,
    }}
  >
    {openNow ? '● Open now' : '● Closed'}
  </span>
);

const BulkBillingTag = () => (
  <span
    style={{
      ...s.tag,
      background: '#FFF4E5',
      color: '#B45309',
    }}
  >
    $ Bulk Billing
  </span>
);

const StarRating = ({ rating }) => {
  const stars = Math.round(rating);
  return (
    <span style={{ color: '#F59E0B', fontSize: '13px', letterSpacing: '-1px' }}>
      {'★'.repeat(stars)}{'☆'.repeat(5 - stars)}
    </span>
  );
};

const ProviderCard = ({ provider, isActive, onClick }) => {
  const [hovered, setHovered] = React.useState(false);

  const cardStyle = {
    ...s.card,
    ...(hovered ? s.cardHovered : {}),
    ...(isActive ? s.cardActive : {}),
  };

  return (
    <article
      style={cardStyle}
      onClick={() => onClick(provider)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      role="button"
      tabIndex={0}
      aria-label={`View details for ${provider.name}`}
      onKeyDown={(e) => e.key === 'Enter' && onClick(provider)}
    >
      {provider.bupaMember && <span style={s.bupaBadge}>BUPA MEMBER</span>}

      <div style={s.topRow}>
        <div
          style={{
            ...s.avatar,
            background: getAvatarColor(provider.name),
          }}
        >
          {provider.type === 'hospital'
            ? <HospitalIcon />
            : getInitials(provider.name)
          }
        </div>

        <div style={s.info}>
          <div style={s.nameRow}>
            <span style={s.name}>{provider.name}</span>
            <span style={s.distanceBadge}>{formatDistance(provider.distance)}</span>
          </div>
          <div style={s.specialty}>{provider.typeLabel}</div>
          <div style={s.practice}>{provider.practice}</div>
          <div style={s.address}>
            <LocationPinIcon />
            <span>{provider.address}</span>
          </div>
        </div>
      </div>

      <div style={s.divider} />

      <div style={s.tagRow}>
        <AcceptingTag accepting={provider.acceptingNewPatients} />
        <OpenNowTag openNow={provider.openNow} />
        {provider.bulkBilling && <BulkBillingTag />}
      </div>

      <div style={s.bottomRow}>
        <a
          href={`tel:${provider.phone}`}
          style={s.phoneLink}
          onClick={(e) => e.stopPropagation()}
          aria-label={`Call ${provider.name}`}
        >
          <PhoneIcon />
          {provider.phone}
        </a>

        {provider.rating > 0 && (
          <div style={s.ratingRow}>
            <StarRating rating={provider.rating} />
            <span style={s.ratingText}>{provider.rating}</span>
            <span style={s.reviewCount}>({provider.reviewCount})</span>
          </div>
        )}
      </div>
    </article>
  );
};

// ─── Icons ─────────────────────────────────────────────────────────────────
const LocationPinIcon = () => (
  <svg width="12" height="14" viewBox="0 0 12 14" fill="none" style={{ flexShrink: 0, marginTop: '2px' }}>
    <path d="M6 0C3.79 0 2 1.79 2 4c0 3 4 8 4 8s4-5 4-8c0-2.21-1.79-4-4-4zm0 5.5C5.17 5.5 4.5 4.83 4.5 4S5.17 2.5 6 2.5 7.5 3.17 7.5 4 6.83 5.5 6 5.5z" fill={theme.colors.gray400} />
  </svg>
);

const PhoneIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M2.5 1h2.1l1 2.5L4.3 4.8C5.1 6.4 6.6 7.9 8.2 8.7l1.3-1.3L12 8.4v2.1c0 .8-.6 1.5-1.4 1.5C4.2 12 1 8.8 1 4.9 1 4.1 1.7 3.5 2.5 3.5V1z" stroke={theme.colors.bupaBlue} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const HospitalIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
    <path d="M12 2L3 7v14h18V7L12 2zm1 13h-2v-3H8v-2h3V7h2v3h3v2h-3v3z" fill="white"/>
  </svg>
);

export default ProviderCard;
