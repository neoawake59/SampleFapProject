// PrimaryInput - shared design system input component (simulates @/shades input)
// Mirrors: src/packages/common/ui/src/PrimaryInput/index.jsx

import React, { forwardRef } from 'react';
import { theme } from '../../../constants/src/index';

const styles = {
  wrapper: {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
    width: '100%',
  },
  label: {
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.semibold,
    color: theme.colors.gray700,
    letterSpacing: '0.01em',
  },
  inputWrap: {
    position: 'relative',
    display: 'flex',
    alignItems: 'center',
  },
  input: {
    width: '100%',
    height: '48px',
    padding: '0 16px',
    fontSize: theme.typography.sizes.base,
    color: theme.colors.gray800,
    background: theme.colors.white,
    border: `1.5px solid ${theme.colors.gray300}`,
    borderRadius: theme.radii.md,
    transition: theme.transitions.fast,
    outline: 'none',
  },
  inputFocused: {
    borderColor: theme.colors.bupaBlue,
    boxShadow: `0 0 0 3px ${theme.colors.bupaLightBlue}`,
  },
  select: {
    width: '100%',
    height: '48px',
    padding: '0 40px 0 16px',
    fontSize: theme.typography.sizes.base,
    color: theme.colors.gray800,
    background: theme.colors.white,
    border: `1.5px solid ${theme.colors.gray300}`,
    borderRadius: theme.radii.md,
    transition: theme.transitions.fast,
    outline: 'none',
    appearance: 'none',
    cursor: 'pointer',
  },
  iconLeft: {
    position: 'absolute',
    left: '14px',
    display: 'flex',
    alignItems: 'center',
    color: theme.colors.gray400,
    pointerEvents: 'none',
  },
  iconRight: {
    position: 'absolute',
    right: '14px',
    display: 'flex',
    alignItems: 'center',
    color: theme.colors.gray400,
    pointerEvents: 'none',
  },
  error: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.error,
    marginTop: '2px',
  },
  hint: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.gray500,
    marginTop: '2px',
  },
};

// ─── Text / Search Input ──────────────────────────────────────────────────
export const PrimaryInput = forwardRef(({
  label,
  id,
  type = 'text',
  placeholder,
  value,
  onChange,
  onFocus,
  onBlur,
  onKeyDown,
  iconLeft,
  iconRight,
  error,
  hint,
  disabled,
  autoComplete,
  ...rest
}, ref) => {
  const [focused, setFocused] = React.useState(false);

  const inputStyle = {
    ...styles.input,
    ...(iconLeft ? { paddingLeft: '44px' } : {}),
    ...(iconRight ? { paddingRight: '44px' } : {}),
    ...(focused ? styles.inputFocused : {}),
    ...(error ? { borderColor: theme.colors.error } : {}),
    ...(disabled ? { background: theme.colors.gray100, color: theme.colors.gray400, cursor: 'not-allowed' } : {}),
  };

  return (
    <div style={styles.wrapper}>
      {label && <label htmlFor={id} style={styles.label}>{label}</label>}
      <div style={styles.inputWrap}>
        {iconLeft && <span style={styles.iconLeft}>{iconLeft}</span>}
        <input
          ref={ref}
          id={id}
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          onFocus={(e) => { setFocused(true); onFocus && onFocus(e); }}
          onBlur={(e) => { setFocused(false); onBlur && onBlur(e); }}
          onKeyDown={onKeyDown}
          disabled={disabled}
          autoComplete={autoComplete}
          style={inputStyle}
          {...rest}
        />
        {iconRight && <span style={styles.iconRight}>{iconRight}</span>}
      </div>
      {error && <span style={styles.error}>{error}</span>}
      {hint && !error && <span style={styles.hint}>{hint}</span>}
    </div>
  );
});

// ─── Select / Dropdown ────────────────────────────────────────────────────
export const PrimarySelect = ({ label, id, value, onChange, options, disabled, ...rest }) => {
  const [focused, setFocused] = React.useState(false);

  const selectStyle = {
    ...styles.select,
    ...(focused ? styles.inputFocused : {}),
    ...(disabled ? { background: theme.colors.gray100, color: theme.colors.gray400, cursor: 'not-allowed' } : {}),
  };

  return (
    <div style={styles.wrapper}>
      {label && <label htmlFor={id} style={styles.label}>{label}</label>}
      <div style={styles.inputWrap}>
        <select
          id={id}
          value={value}
          onChange={onChange}
          disabled={disabled}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={selectStyle}
          {...rest}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
        <span style={styles.iconRight}>
          <ChevronDownIcon />
        </span>
      </div>
    </div>
  );
};

// ─── Checkbox filter ──────────────────────────────────────────────────────
export const FilterCheckbox = ({ id, label, checked, onChange }) => (
  <label
    htmlFor={id}
    style={{
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: theme.typography.sizes.sm,
      color: theme.colors.gray700,
      cursor: 'pointer',
      userSelect: 'none',
      fontWeight: checked ? theme.typography.weights.medium : theme.typography.weights.regular,
    }}
  >
    <input
      type="checkbox"
      id={id}
      checked={checked}
      onChange={onChange}
      style={{
        width: '18px',
        height: '18px',
        accentColor: theme.colors.bupaBlue,
        cursor: 'pointer',
        flexShrink: 0,
      }}
    />
    {label}
  </label>
);

// ─── Mini icon ─────────────────────────────────────────────────────────────
const ChevronDownIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export default PrimaryInput;
