// Common Hooks
// Mirrors: src/packages/common/hooks/src/index.js

import { useState, useEffect, useRef, useCallback } from 'react';

// ─── useShouldFocus ───────────────────────────────────────────────────────
// Manages focus for accessibility (e.g., focus first result after search)
export const useShouldFocus = (condition) => {
  const ref = useRef(null);
  useEffect(() => {
    if (condition && ref.current) {
      ref.current.focus();
    }
  }, [condition]);
  return ref;
};

// ─── useIsScrolling ───────────────────────────────────────────────────────
// Detects whether the user is actively scrolling
export const useIsScrolling = (element = null, delay = 150) => {
  const [isScrolling, setIsScrolling] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    const target = element || window;
    const handleScroll = () => {
      setIsScrolling(true);
      clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => setIsScrolling(false), delay);
    };
    target.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      target.removeEventListener('scroll', handleScroll);
      clearTimeout(timerRef.current);
    };
  }, [element, delay]);

  return isScrolling;
};

// ─── useMediaQuery ───────────────────────────────────────────────────────
export const useMediaQuery = (query) => {
  const [matches, setMatches] = useState(() => window.matchMedia(query).matches);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const handler = (e) => setMatches(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [query]);
  return matches;
};

// ─── useClickOutside ─────────────────────────────────────────────────────
export const useClickOutside = (callback) => {
  const ref = useRef(null);
  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) callback();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [callback]);
  return ref;
};

// ─── useDebounce ──────────────────────────────────────────────────────────
export const useDebounce = (value, delay = 300) => {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
};

// ─── useSticky ───────────────────────────────────────────────────────────
// Returns true when element has scrolled past a threshold (for sticky behavior)
export const useSticky = (threshold = 0) => {
  const [isSticky, setIsSticky] = useState(false);
  useEffect(() => {
    const handleScroll = () => setIsSticky(window.scrollY > threshold);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [threshold]);
  return isSticky;
};

// ─── usePagination ───────────────────────────────────────────────────────
export const usePagination = (totalItems, pageSize) => {
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = Math.ceil(totalItems / pageSize);

  const goToPage = useCallback((page) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  }, [totalPages]);

  const nextPage = useCallback(() => goToPage(currentPage + 1), [currentPage, goToPage]);
  const prevPage = useCallback(() => goToPage(currentPage - 1), [currentPage, goToPage]);

  const reset = useCallback(() => setCurrentPage(1), []);

  return { currentPage, totalPages, goToPage, nextPage, prevPage, reset };
};
