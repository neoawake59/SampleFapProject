// Common Constants - simulates @/shades design tokens and shared config
// Mirrors: src/packages/common/constants/src/index.js

// ─── Design System Tokens (simulates @/shades) ────────────────────────────
export const theme = {
  colors: {
    bupaNavy:      '#003057',
    bupaBlue:      '#00AEEF',
    bupaLightBlue: '#E6F6FD',
    bupaGreen:     '#00A551',
    bupaRed:       '#D0021B',
    bupaOrange:    '#F7941D',

    white:  '#FFFFFF',
    offWhite: '#F5F7FA',
    gray50:  '#FAFAFA',
    gray100: '#F0F2F5',
    gray200: '#E0E4EC',
    gray300: '#C7CDD9',
    gray400: '#9AA3B2',
    gray500: '#6B7280',
    gray600: '#4B5563',
    gray700: '#374151',
    gray800: '#1F2937',
    gray900: '#111827',

    success: '#00A551',
    warning: '#F59E0B',
    error:   '#D0021B',
    info:    '#00AEEF',
  },

  typography: {
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    sizes: {
      xs:   '11px',
      sm:   '13px',
      base: '15px',
      md:   '17px',
      lg:   '20px',
      xl:   '24px',
      '2xl':'30px',
      '3xl':'36px',
    },
    weights: {
      regular:  400,
      medium:   500,
      semibold: 600,
      bold:     700,
    },
    lineHeights: {
      tight:  1.2,
      snug:   1.375,
      normal: 1.5,
    },
  },

  spacing: {
    1: '4px',
    2: '8px',
    3: '12px',
    4: '16px',
    5: '20px',
    6: '24px',
    8: '32px',
    10: '40px',
    12: '48px',
    16: '64px',
  },

  radii: {
    sm:   '4px',
    base: '6px',
    md:   '8px',
    lg:   '12px',
    xl:   '16px',
    full: '9999px',
  },

  shadows: {
    sm:  '0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)',
    base:'0 2px 8px rgba(0,0,0,0.10), 0 1px 3px rgba(0,0,0,0.06)',
    md:  '0 4px 16px rgba(0,0,0,0.12), 0 2px 6px rgba(0,0,0,0.06)',
    lg:  '0 8px 32px rgba(0,0,0,0.14), 0 4px 12px rgba(0,0,0,0.06)',
  },

  transitions: {
    fast:   'all 0.15s ease',
    base:   'all 0.25s ease',
    slow:   'all 0.35s ease',
  },
};

// ─── Breakpoints ─────────────────────────────────────────────────────────
export const breakpoints = {
  sm:  576,
  md:  768,
  lg:  1024,
  xl:  1280,
  '2xl': 1536,
};

// ─── URL Params ───────────────────────────────────────────────────────────
export const urlParams = {
  QUERY:      'q',
  LOCATION:   'location',
  SUBURB:     'suburb',
  POSTCODE:   'postcode',
  LATITUDE:   'lat',
  LONGITUDE:  'lng',
  DISTANCE:   'distance',
  GENDER:     'gender',
  LANGUAGE:   'language',
  OPEN_NOW:   'openNow',
  ACCEPTING:  'accepting',
  PAGE:       'page',
  VIEW:       'view',
  PROVIDER_ID:'providerId',
};

// ─── Analytics events ────────────────────────────────────────────────────
export const analyticsEvents = {
  SEARCH_SUBMITTED:      'find_provider_search_submitted',
  FILTER_APPLIED:        'find_provider_filter_applied',
  PROVIDER_CARD_CLICKED: 'find_provider_card_clicked',
  DETAIL_VIEWED:         'find_provider_detail_viewed',
  MAP_PIN_CLICKED:       'find_provider_map_pin_clicked',
  VIEW_TOGGLED:          'find_provider_view_toggled',
  PAGINATION_NEXT:       'find_provider_pagination_next',
};

// ─── Provider type options ────────────────────────────────────────────────
export const providerTypes = [
  { value: '',              label: 'All provider types' },
  { value: 'gp',            label: 'General Practitioner (GP)' },
  { value: 'specialist',    label: 'Specialist' },
  { value: 'dentist',       label: 'Dentist' },
  { value: 'physiotherapist', label: 'Physiotherapist' },
  { value: 'psychologist',  label: 'Psychologist' },
  { value: 'optometrist',   label: 'Optometrist' },
  { value: 'podiatrist',    label: 'Podiatrist' },
  { value: 'chiropractor',  label: 'Chiropractor' },
  { value: 'dietitian',     label: 'Dietitian' },
  { value: 'hospital',      label: 'Hospital' },
];

// ─── Distance options ─────────────────────────────────────────────────────
export const distanceOptions = [
  { value: 2,   label: 'Within 2 km' },
  { value: 5,   label: 'Within 5 km' },
  { value: 10,  label: 'Within 10 km' },
  { value: 20,  label: 'Within 20 km' },
  { value: 50,  label: 'Within 50 km' },
];

// ─── Gender options ───────────────────────────────────────────────────────
export const genderOptions = [
  { value: '',       label: 'Any gender' },
  { value: 'female', label: 'Female' },
  { value: 'male',   label: 'Male' },
];

// ─── Language options ─────────────────────────────────────────────────────
export const languageOptions = [
  { value: '',          label: 'Any language' },
  { value: 'english',   label: 'English' },
  { value: 'mandarin',  label: 'Mandarin' },
  { value: 'cantonese', label: 'Cantonese' },
  { value: 'arabic',    label: 'Arabic' },
  { value: 'hindi',     label: 'Hindi' },
  { value: 'greek',     label: 'Greek' },
  { value: 'italian',   label: 'Italian' },
  { value: 'vietnamese','label': 'Vietnamese' },
];

// ─── Results per page ─────────────────────────────────────────────────────
export const PAGE_SIZE = 6;
