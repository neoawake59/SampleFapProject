// Common Utilities - simulates @/valhalla helpers + common/utilities
// Mirrors: src/packages/common/utilities/src/index.js

// ─── Geolocation ──────────────────────────────────────────────────────────
export const geolocation = {
  getCurrentPosition: () =>
    new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser.'));
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => reject(err),
        { timeout: 8000, maximumAge: 300000 }
      );
    }),

  reverseGeocode: async (lat, lng) => {
    // Simulated reverse geocode (no real API call)
    return { suburb: 'Melbourne CBD', postcode: '3000', state: 'VIC' };
  },
};

// ─── Analytics (stub) ─────────────────────────────────────────────────────
export const analytics = {
  track: (event, data = {}) => {
    // Simulates analytics dispatch
    if (process.env.NODE_ENV === 'development') {
      console.info('[Analytics]', event, data);
    }
  },
};

// ─── String helpers ───────────────────────────────────────────────────────
export const formatDistance = (km) => {
  if (km < 1) return `${Math.round(km * 1000)} m away`;
  return `${km.toFixed(1)} km away`;
};

export const formatPhone = (phone) => {
  return phone.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2 $3');
};

export const getInitials = (name) => {
  return name
    .split(' ')
    .filter((_, i) => i === 0 || i === name.split(' ').length - 1)
    .map((n) => n[0])
    .join('')
    .toUpperCase();
};

// ─── Throttle ────────────────────────────────────────────────────────────
export const throttle = (fn, delay) => {
  let last = 0;
  return (...args) => {
    const now = Date.now();
    if (now - last >= delay) {
      last = now;
      return fn(...args);
    }
  };
};

// ─── Debounce ─────────────────────────────────────────────────────────────
export const debounce = (fn, delay) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
};

// ─── URL helpers (simulates UriState helpers) ─────────────────────────────
export const urlHelper = {
  getParam: (key) => {
    const params = new URLSearchParams(window.location.search);
    return params.get(key);
  },
  setParams: (updates) => {
    const params = new URLSearchParams(window.location.search);
    Object.entries(updates).forEach(([k, v]) => {
      if (v === null || v === undefined || v === '') {
        params.delete(k);
      } else {
        params.set(k, v);
      }
    });
    const newUrl = `${window.location.pathname}?${params.toString()}`;
    window.history.replaceState(null, '', newUrl);
  },
  clearAll: () => {
    window.history.replaceState(null, '', window.location.pathname);
  },
};

// ─── Avatar color generator ───────────────────────────────────────────────
const AVATAR_COLORS = [
  '#003057', '#00AEEF', '#00A551', '#7C3AED', '#D97706',
  '#0F766E', '#B91C1C', '#1D4ED8',
];

export const getAvatarColor = (name) => {
  const index = name.charCodeAt(0) % AVATAR_COLORS.length;
  return AVATAR_COLORS[index];
};

// ─── Filter helpers ───────────────────────────────────────────────────────
export const filterProviders = (providers, filters) => {
  return providers.filter((p) => {
    if (filters.providerType && p.type !== filters.providerType) return false;
    if (filters.distance && p.distance > filters.distance) return false;
    if (filters.gender && p.gender.toLowerCase() !== filters.gender) return false;
    if (filters.language && !p.languages.map((l) => l.toLowerCase()).includes(filters.language)) return false;
    if (filters.openNow && !p.openNow) return false;
    if (filters.acceptingNewPatients && !p.acceptingNewPatients) return false;
    return true;
  });
};
