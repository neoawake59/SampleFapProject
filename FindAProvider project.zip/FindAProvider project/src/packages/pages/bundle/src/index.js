// Bundle Entry - registers and imports all feature components
// This simulates the bundle entry that registers custom elements
// Mirrors: src/packages/pages/bundle/src/index.js

// In a real Valhalla/web-components setup, this would call:
//   element('find-and-book.search', SearchFeature)
//   element('find-and-book.search-result', SearchResultFeature)
//   etc.
//
// Here we simply re-export all features for composition in App.jsx

export { default as SearchFeature } from '../../../features/search/src/index';
export { default as SearchResultFeature } from '../../../features/search-result/src/index';
export { default as PageTitleFeature } from '../../../features/page-title/src/index';
export { default as DetailFeature } from '../../../features/detail/src/index';
