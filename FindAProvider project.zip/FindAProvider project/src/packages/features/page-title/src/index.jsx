// PageTitleFeature - renders the page heading and breadcrumb
// Mirrors: src/packages/features/page-title/src/index.jsx

import React from 'react';
import { theme } from '../../../common/constants/src/index';

const s = {
  wrapper: {
    background: theme.colors.bupaNavy,
    color: theme.colors.white,
    paddingTop: '28px',
    paddingBottom: '28px',
  },
  inner: {
    maxWidth: '1280px',
    margin: '0 auto',
    padding: '0 24px',
  },
  breadcrumb: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    fontSize: theme.typography.sizes.sm,
    color: 'rgba(255,255,255,0.65)',
    marginBottom: '10px',
  },
  breadcrumbLink: {
    color: 'rgba(255,255,255,0.65)',
    textDecoration: 'none',
    transition: theme.transitions.fast,
  },
  separator: {
    fontSize: '10px',
    opacity: 0.5,
  },
  activeCrumb: {
    color: 'rgba(255,255,255,0.9)',
  },
  heading: {
    fontSize: theme.typography.sizes['2xl'],
    fontWeight: theme.typography.weights.bold,
    lineHeight: theme.typography.lineHeights.tight,
    marginBottom: '8px',
  },
  subheading: {
    fontSize: theme.typography.sizes.base,
    color: 'rgba(255,255,255,0.75)',
    maxWidth: '540px',
    lineHeight: theme.typography.lineHeights.normal,
  },
};

const PageTitleFeature = () => (
  <section style={s.wrapper} aria-label="Page title">
    <div style={s.inner}>
      <nav style={s.breadcrumb} aria-label="Breadcrumb">
        <a href="/" style={s.breadcrumbLink}>Home</a>
        <span style={s.separator}>›</span>
        <a href="/health-insurance" style={s.breadcrumbLink}>Health Insurance</a>
        <span style={s.separator}>›</span>
        <span style={s.activeCrumb}>Find a Provider</span>
      </nav>
      <h1 style={s.heading}>Find a provider</h1>
      <p style={s.subheading}>
        Search for in-hospital and ancillary providers who recognise your Bupa health cover.
      </p>
    </div>
  </section>
);

export default PageTitleFeature;
