// DetailFeature - provider detail side drawer/panel
// Mirrors: src/packages/features/detail/src/index.jsx

import React, { useEffect, useRef } from 'react';
import { theme } from '../../../common/constants/src/index';
import { getInitials, getAvatarColor, formatDistance } from '../../../common/utilities/src/index';
import { useShouldFocus } from '../../../common/hooks/src/index';

const s = {
  overlay: {
    position: 'fixed',
    inset: 0,
    background: 'rgba(0, 30, 57, 0.45)',
    zIndex: 200,
    display: 'flex',
    justifyContent: 'flex-end',
    animation: 'fadeIn 0.2s ease',
  },
  drawer: {
    width: '100%',
    maxWidth: '520px',
    height: '100%',
    background: theme.colors.white,
    overflowY: 'auto',
    boxShadow: theme.shadows.lg,
    animation: 'slideInRight 0.3s ease',
    display: 'flex',
    flexDirection: 'column',
  },
  header: {
    background: theme.colors.bupaNavy,
    color: theme.colors.white,
    padding: '20px 24px',
    position: 'sticky',
    top: 0,
    zIndex: 10,
    flexShrink: 0,
  },
  closeRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '16px',
  },
  backBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    fontSize: theme.typography.sizes.sm,
    color: 'rgba(255,255,255,0.8)',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '4px 0',
    transition: theme.transitions.fast,
  },
  headerAvatar: {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
  },
  avatar: {
    width: '64px',
    height: '64px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '22px',
    fontWeight: theme.typography.weights.bold,
    color: theme.colors.white,
    flexShrink: 0,
    border: '3px solid rgba(255,255,255,0.3)',
  },
  providerName: {
    fontSize: theme.typography.sizes.xl,
    fontWeight: theme.typography.weights.bold,
    lineHeight: theme.typography.lineHeights.tight,
    marginBottom: '4px',
  },
  providerSpecialty: {
    fontSize: theme.typography.sizes.base,
    color: theme.colors.bupaBlue,
    marginBottom: '2px',
  },
  providerPractice: {
    fontSize: theme.typography.sizes.sm,
    color: 'rgba(255,255,255,0.75)',
  },
  body: {
    flex: 1,
    padding: '24px',
  },
  section: {
    marginBottom: '28px',
  },
  sectionTitle: {
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.bold,
    color: theme.colors.gray500,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    marginBottom: '12px',
  },
  infoRow: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '10px',
    marginBottom: '10px',
    fontSize: theme.typography.sizes.base,
    color: theme.colors.gray700,
    lineHeight: theme.typography.lineHeights.normal,
  },
  infoIcon: {
    flexShrink: 0,
    marginTop: '2px',
    color: theme.colors.gray400,
  },
  tagRow: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '8px',
    marginBottom: '4px',
  },
  tag: {
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.medium,
    borderRadius: theme.radii.full,
    padding: '4px 12px',
  },
  hoursTable: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  hoursRow: {
    display: 'grid',
    gridTemplateColumns: '80px 1fr',
    gap: '8px',
    padding: '6px 0',
    borderBottom: `1px solid ${theme.colors.gray100}`,
    fontSize: theme.typography.sizes.sm,
  },
  hoursDayLabel: {
    fontWeight: theme.typography.weights.medium,
    color: theme.colors.gray600,
  },
  hoursValue: {
    color: theme.colors.gray700,
  },
  serviceChip: {
    display: 'inline-flex',
    alignItems: 'center',
    padding: '5px 12px',
    background: theme.colors.bupaLightBlue,
    color: theme.colors.bupaNavy,
    borderRadius: theme.radii.full,
    fontSize: theme.typography.sizes.xs,
    fontWeight: theme.typography.weights.medium,
    marginRight: '6px',
    marginBottom: '6px',
  },
  cta: {
    padding: '20px 24px',
    borderTop: `1px solid ${theme.colors.gray100}`,
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    background: theme.colors.white,
    flexShrink: 0,
    position: 'sticky',
    bottom: 0,
  },
  primaryBtn: {
    width: '100%',
    height: '52px',
    background: theme.colors.bupaBlue,
    color: theme.colors.white,
    borderRadius: theme.radii.md,
    fontSize: theme.typography.sizes.base,
    fontWeight: theme.typography.weights.semibold,
    border: 'none',
    cursor: 'pointer',
    transition: theme.transitions.fast,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
  },
  secondaryBtn: {
    width: '100%',
    height: '48px',
    background: theme.colors.white,
    color: theme.colors.bupaBlue,
    borderRadius: theme.radii.md,
    fontSize: theme.typography.sizes.base,
    fontWeight: theme.typography.weights.semibold,
    border: `1.5px solid ${theme.colors.bupaBlue}`,
    cursor: 'pointer',
    transition: theme.transitions.fast,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
  },
  ratingRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    marginBottom: '16px',
  },
  starsLarge: {
    color: '#F59E0B',
    fontSize: '22px',
    letterSpacing: '-1px',
  },
  ratingNumber: {
    fontSize: theme.typography.sizes.xl,
    fontWeight: theme.typography.weights.bold,
    color: theme.colors.gray900,
  },
  reviewCount: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.gray400,
  },
  divider: {
    height: '1px',
    background: theme.colors.gray100,
    margin: '4px 0 20px',
  },
};

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const DetailFeature = ({ provider, onClose }) => {
  const closeRef = useShouldFocus(true);

  // Close on Escape
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  // Prevent body scroll when open
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  const today = DAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1];

  const stars = Math.round(provider.rating);

  return (
    <div
      style={s.overlay}
      onClick={(e) => e.target === e.currentTarget && onClose()}
      role="dialog"
      aria-modal="true"
      aria-label={`Provider details for ${provider.name}`}
    >
      <div style={s.drawer}>
        {/* Header */}
        <div style={s.header}>
          <div style={s.closeRow}>
            <button
              ref={closeRef}
              style={s.backBtn}
              onClick={onClose}
              aria-label="Close provider details"
            >
              <ArrowLeftIcon /> Back to results
            </button>

            {provider.bupaMember && (
              <span style={{
                fontSize: '11px',
                fontWeight: theme.typography.weights.bold,
                background: 'rgba(0,174,239,0.25)',
                color: theme.colors.bupaBlue,
                borderRadius: theme.radii.full,
                padding: '3px 10px',
                letterSpacing: '0.04em',
              }}>
                BUPA MEMBER
              </span>
            )}
          </div>

          <div style={s.headerAvatar}>
            <div
              style={{
                ...s.avatar,
                background: getAvatarColor(provider.name),
              }}
            >
              {provider.type === 'hospital' ? '🏥' : getInitials(provider.name)}
            </div>
            <div>
              <div style={s.providerName}>{provider.name}</div>
              <div style={s.providerSpecialty}>{provider.typeLabel}</div>
              <div style={s.providerPractice}>{provider.practice}</div>
            </div>
          </div>
        </div>

        {/* Body */}
        <div style={s.body}>
          {/* Rating */}
          {provider.rating > 0 && (
            <div>
              <div style={s.ratingRow}>
                <span style={s.starsLarge}>
                  {'★'.repeat(stars)}{'☆'.repeat(5 - stars)}
                </span>
                <span style={s.ratingNumber}>{provider.rating}</span>
                <span style={s.reviewCount}>({provider.reviewCount} reviews)</span>
              </div>
              <div style={s.divider} />
            </div>
          )}

          {/* Status tags */}
          <div style={{ ...s.section, marginBottom: '16px' }}>
            <div style={s.tagRow}>
              <span style={{
                ...s.tag,
                background: provider.acceptingNewPatients ? '#E8F9F0' : '#FFF0F0',
                color: provider.acceptingNewPatients ? theme.colors.bupaGreen : theme.colors.bupaRed,
              }}>
                {provider.acceptingNewPatients ? '✓ Accepting new patients' : '✗ Not accepting new patients'}
              </span>

              <span style={{
                ...s.tag,
                background: provider.openNow ? '#E8F9F0' : theme.colors.gray100,
                color: provider.openNow ? theme.colors.bupaGreen : theme.colors.gray500,
              }}>
                {provider.openNow ? '● Open now' : '● Currently closed'}
              </span>

              {provider.bulkBilling && (
                <span style={{ ...s.tag, background: '#FFF4E5', color: '#B45309' }}>
                  $ Bulk Billing available
                </span>
              )}
            </div>
          </div>

          {/* Contact & location */}
          <div style={s.section}>
            <div style={s.sectionTitle}>Contact & Location</div>

            <div style={s.infoRow}>
              <span style={s.infoIcon}><LocationIcon /></span>
              <div>
                <div>{provider.address}</div>
                <div style={{ fontSize: theme.typography.sizes.sm, color: theme.colors.gray400, marginTop: '2px' }}>
                  {formatDistance(provider.distance)}
                </div>
              </div>
            </div>

            <div style={s.infoRow}>
              <span style={s.infoIcon}><PhoneIcon /></span>
              <a
                href={`tel:${provider.phone}`}
                style={{ color: theme.colors.bupaBlue, fontWeight: theme.typography.weights.medium }}
              >
                {provider.phone}
              </a>
            </div>

            <div style={s.infoRow}>
              <span style={s.infoIcon}><PersonIcon /></span>
              <span>
                {provider.gender !== 'N/A' ? `${provider.gender} provider` : 'Mixed / Team practice'}
              </span>
            </div>

            <div style={s.infoRow}>
              <span style={s.infoIcon}><GlobeIcon /></span>
              <span>{provider.languages.join(', ')}</span>
            </div>
          </div>

          {/* Opening hours */}
          <div style={s.section}>
            <div style={s.sectionTitle}>Opening Hours</div>
            <div>
              {DAYS.map((day) => (
                <div
                  key={day}
                  style={{
                    ...s.hoursRow,
                    ...(day === today ? {
                      background: theme.colors.bupaLightBlue,
                      borderRadius: theme.radii.base,
                      padding: '6px 8px',
                    } : {}),
                  }}
                >
                  <span style={{
                    ...s.hoursDayLabel,
                    ...(day === today ? { color: theme.colors.bupaNavy, fontWeight: theme.typography.weights.bold } : {}),
                  }}>
                    {day === today ? `${day} (today)` : day}
                  </span>
                  <span style={{
                    ...s.hoursValue,
                    color: provider.hours[day] === 'Closed' ? theme.colors.bupaRed : theme.colors.gray700,
                  }}>
                    {provider.hours[day] || 'Closed'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Services */}
          <div style={s.section}>
            <div style={s.sectionTitle}>Services</div>
            <div>
              {provider.services.map((service) => (
                <span key={service} style={s.serviceChip}>{service}</span>
              ))}
            </div>
          </div>
        </div>

        {/* CTA footer */}
        <div style={s.cta}>
          <button style={s.primaryBtn} aria-label="Book an appointment">
            <CalendarIcon />
            Book an appointment
          </button>
          <button
            style={s.secondaryBtn}
            onClick={() => window.open(`tel:${provider.phone}`)}
            aria-label={`Call ${provider.phone}`}
          >
            <PhoneIcon color={theme.colors.bupaBlue} />
            Call {provider.phone}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Icons ─────────────────────────────────────────────────────────────────
const ArrowLeftIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <path d="M10 12L6 8l4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const LocationIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <path d="M8 1C5.24 1 3 3.24 3 6c0 3.75 5 9 5 9s5-5.25 5-9c0-2.76-2.24-5-5-5zm0 6.75A1.75 1.75 0 116 6a1.75 1.75 0 012 1.75z" fill="currentColor"/>
  </svg>
);

const PhoneIcon = ({ color = 'currentColor' }) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <path d="M2.5 1h2.1l1.1 2.8L4.3 5.1c.9 1.8 2.8 3.7 4.6 4.6l1.3-1.4L13 9.4v2.1c0 .8-.7 1.5-1.5 1.5C5.2 13 1 8.8 1 3.5c0-.8.7-1.5 1.5-1.5z" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const PersonIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <circle cx="8" cy="5" r="3" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M2 14c0-3.31 2.69-6 6-6s6 2.69 6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

const GlobeIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M8 1.5C8 1.5 5.5 4.5 5.5 8s2.5 6.5 2.5 6.5M8 1.5C8 1.5 10.5 4.5 10.5 8S8 14.5 8 14.5M1.5 8h13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

const CalendarIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <rect x="1.5" y="3.5" width="13" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M5 1.5v3M11 1.5v3M1.5 7h13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

export default DetailFeature;
