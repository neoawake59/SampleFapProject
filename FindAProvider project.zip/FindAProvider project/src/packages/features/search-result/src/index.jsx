// SearchResultFeature - split-view list + map results panel
// Mirrors: src/packages/features/search-result/src/index.jsx

import React, { useState, useCallback } from 'react';
import { useAppState } from '../../../state/src/index';
import { ProviderCard, PrimaryMap } from '../../../common/ui/src/index';
import { theme, PAGE_SIZE, analyticsEvents } from '../../../common/constants/src/index';
import { analytics } from '../../../common/utilities/src/index';
import { useMediaQuery } from '../../../common/hooks/src/index';
import DetailFeature from '../../detail/src/index';

const s = {
  wrapper: {
    maxWidth: '1280px',
    margin: '0 auto',
    padding: '24px 24px 48px',
  },
  viewToggle: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '20px',
    flexWrap: 'wrap',
    gap: '12px',
  },
  toggleGroup: {
    display: 'flex',
    border: `1.5px solid ${theme.colors.gray200}`,
    borderRadius: theme.radii.md,
    overflow: 'hidden',
  },
  toggleBtn: {
    padding: '8px 18px',
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.medium,
    border: 'none',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    transition: theme.transitions.fast,
  },
  toggleBtnActive: {
    background: theme.colors.bupaNavy,
    color: theme.colors.white,
  },
  toggleBtnInactive: {
    background: theme.colors.white,
    color: theme.colors.gray600,
  },
  sortRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.gray600,
  },
  sortSelect: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.gray700,
    border: `1px solid ${theme.colors.gray200}`,
    borderRadius: theme.radii.base,
    padding: '6px 28px 6px 10px',
    appearance: 'none',
    cursor: 'pointer',
    background: theme.colors.white,
    outline: 'none',
    fontFamily: 'inherit',
  },
  splitView: {
    display: 'grid',
    gap: '24px',
  },
  listCol: {
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
  },
  mapCol: {
    position: 'sticky',
    top: '120px',
    height: 'calc(100vh - 160px)',
    minHeight: '400px',
  },
  pagination: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    marginTop: '32px',
    flexWrap: 'wrap',
  },
  pageBtn: {
    width: '40px',
    height: '40px',
    borderRadius: theme.radii.md,
    border: `1.5px solid ${theme.colors.gray200}`,
    background: theme.colors.white,
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.medium,
    color: theme.colors.gray700,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: theme.transitions.fast,
  },
  pageBtnActive: {
    background: theme.colors.bupaNavy,
    borderColor: theme.colors.bupaNavy,
    color: theme.colors.white,
  },
  pageBtnDisabled: {
    opacity: 0.4,
    cursor: 'not-allowed',
  },
  emptyState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '80px 24px',
    textAlign: 'center',
    background: theme.colors.white,
    borderRadius: theme.radii.xl,
    border: `1px solid ${theme.colors.gray200}`,
  },
  emptyIcon: {
    fontSize: '48px',
    marginBottom: '16px',
    opacity: 0.4,
  },
  emptyTitle: {
    fontSize: theme.typography.sizes.lg,
    fontWeight: theme.typography.weights.semibold,
    color: theme.colors.gray800,
    marginBottom: '8px',
  },
  emptyText: {
    fontSize: theme.typography.sizes.base,
    color: theme.colors.gray500,
    maxWidth: '380px',
    lineHeight: theme.typography.lineHeights.normal,
  },
  skeleton: {
    background: theme.colors.white,
    borderRadius: theme.radii.lg,
    border: `1px solid ${theme.colors.gray200}`,
    padding: '20px',
    overflow: 'hidden',
  },
  skeletonLine: {
    height: '14px',
    borderRadius: theme.radii.full,
    background: `linear-gradient(90deg, ${theme.colors.gray100} 25%, ${theme.colors.gray200} 50%, ${theme.colors.gray100} 75%)`,
    backgroundSize: '200% 100%',
    animation: 'shimmer 1.5s infinite',
    marginBottom: '10px',
  },
  welcomeState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '64px 24px',
    textAlign: 'center',
  },
  welcomeTitle: {
    fontSize: theme.typography.sizes.xl,
    fontWeight: theme.typography.weights.semibold,
    color: theme.colors.gray800,
    marginBottom: '12px',
  },
  welcomeText: {
    fontSize: theme.typography.sizes.base,
    color: theme.colors.gray500,
    maxWidth: '480px',
    lineHeight: theme.typography.lineHeights.normal,
    marginBottom: '32px',
  },
  quickLinks: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '12px',
    justifyContent: 'center',
  },
  quickLink: {
    padding: '10px 20px',
    background: theme.colors.white,
    border: `1.5px solid ${theme.colors.gray200}`,
    borderRadius: theme.radii.full,
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.medium,
    color: theme.colors.gray700,
    cursor: 'pointer',
    transition: theme.transitions.fast,
  },
};

const SkeletonCard = () => (
  <div style={s.skeleton}>
    <div style={{ display: 'flex', gap: '14px', marginBottom: '16px' }}>
      <div style={{ width: '52px', height: '52px', borderRadius: '50%', background: theme.colors.gray200, flexShrink: 0 }} />
      <div style={{ flex: 1 }}>
        <div style={{ ...s.skeletonLine, width: '60%' }} />
        <div style={{ ...s.skeletonLine, width: '40%' }} />
        <div style={{ ...s.skeletonLine, width: '80%' }} />
      </div>
    </div>
    <div style={{ ...s.skeletonLine, width: '100%' }} />
    <div style={{ display: 'flex', gap: '8px' }}>
      <div style={{ ...s.skeletonLine, width: '30%', marginBottom: 0 }} />
      <div style={{ ...s.skeletonLine, width: '25%', marginBottom: 0 }} />
    </div>
  </div>
);

const SORT_OPTIONS = [
  { value: 'distance', label: 'Distance (nearest first)' },
  { value: 'rating',   label: 'Rating (highest first)' },
  { value: 'name',     label: 'Name (A–Z)' },
];

const QUICK_SEARCH_TYPES = [
  { label: 'GP near me', type: 'gp' },
  { label: 'Dentist', type: 'dentist' },
  { label: 'Physiotherapist', type: 'physiotherapist' },
  { label: 'Specialist', type: 'specialist' },
  { label: 'Psychologist', type: 'psychologist' },
  { label: 'Hospital', type: 'hospital' },
];

const SearchResultFeature = () => {
  const {
    searchState,
    searchResultState,
    dispatchSearchResult,
    dispatchSearch,
    pagedProviders,
    totalPages,
    performSearch,
  } = useAppState();

  const [selectedProvider, setSelectedProvider] = useState(null);
  const [activeMapPin, setActiveMapPin] = useState(null);
  const [sortBy, setSortBy] = useState('distance');
  const [sortSelectHovered, setSortSelectHovered] = useState(false);

  const isDesktop = useMediaQuery('(min-width: 1024px)');
  const viewMode = searchResultState.viewMode;

  const handleProviderClick = useCallback((provider) => {
    setSelectedProvider(provider);
    analytics.track(analyticsEvents.PROVIDER_CARD_CLICKED, { providerId: provider.id });
  }, []);

  const handleDetailClose = useCallback(() => setSelectedProvider(null), []);

  const handleMapPinClick = useCallback((provider) => {
    setSelectedProvider(provider);
    setActiveMapPin(provider.id);
    analytics.track(analyticsEvents.MAP_PIN_CLICKED, { providerId: provider.id });
  }, []);

  const handleViewChange = (mode) => {
    dispatchSearchResult({ type: 'RESULTS_SET_VIEW_MODE', payload: mode });
    analytics.track(analyticsEvents.VIEW_TOGGLED, { view: mode });
  };

  const handlePageChange = (page) => {
    dispatchSearchResult({ type: 'RESULTS_SET_PAGE', payload: page });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickSearch = (type) => {
    dispatchSearch({ type: 'SEARCH_UPDATE_VALUES', payload: { providerType: type } });
    performSearch({ providerType: type });
  };

  // Sort providers
  const sortedProviders = [...pagedProviders].sort((a, b) => {
    if (sortBy === 'distance') return a.distance - b.distance;
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    return 0;
  });

  const { isLoading, hasResults, totalCount, currentPage } = searchResultState;
  const hasSearched = searchState.hasSearched;

  // ── Grid columns based on view mode ──────────────────────────────────
  const gridCols = {
    split: isDesktop ? '1fr 1fr' : '1fr',
    list: '1fr',
    map: '0 1fr',
  };

  // ── Welcome / pre-search state ────────────────────────────────────────
  if (!hasSearched && !isLoading) {
    return (
      <div style={s.wrapper}>
        <div style={s.welcomeState}>
          <div style={{ fontSize: '64px', marginBottom: '16px' }}>🏥</div>
          <h2 style={s.welcomeTitle}>Find a healthcare provider near you</h2>
          <p style={s.welcomeText}>
            Search by provider type and location above, or try one of the common searches below.
          </p>
          <div style={s.quickLinks}>
            {QUICK_SEARCH_TYPES.map((qs) => (
              <QuickLinkBtn key={qs.type} label={qs.label} onClick={() => handleQuickSearch(qs.type)} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div style={s.wrapper}>
        {/* View toggle + sort */}
        <div style={s.viewToggle}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={s.toggleGroup} role="group" aria-label="View mode">
              {[
                { mode: 'list', label: 'List', Icon: ListIcon },
                { mode: 'split', label: 'Split', Icon: SplitIcon },
                { mode: 'map', label: 'Map', Icon: MapToggleIcon },
              ].map(({ mode, label, Icon }) => (
                <button
                  key={mode}
                  style={{
                    ...s.toggleBtn,
                    ...(viewMode === mode ? s.toggleBtnActive : s.toggleBtnInactive),
                  }}
                  onClick={() => handleViewChange(mode)}
                  aria-pressed={viewMode === mode}
                  aria-label={`${label} view`}
                >
                  <Icon active={viewMode === mode} />
                  {label}
                </button>
              ))}
            </div>

            {hasResults && (
              <span style={{ fontSize: theme.typography.sizes.sm, color: theme.colors.gray500 }}>
                {totalCount} {totalCount === 1 ? 'result' : 'results'}
              </span>
            )}
          </div>

          {hasResults && viewMode !== 'map' && (
            <div style={s.sortRow}>
              <span>Sort by:</span>
              <div style={{ position: 'relative' }}>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  style={s.sortSelect}
                  aria-label="Sort results"
                >
                  {SORT_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Main content grid */}
        <div
          style={{
            ...s.splitView,
            gridTemplateColumns: gridCols[viewMode] || '1fr 1fr',
          }}
        >
          {/* List column */}
          {viewMode !== 'map' && (
            <div style={s.listCol} aria-label="Provider results list" aria-live="polite">
              {isLoading
                ? Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)
                : !hasResults
                ? <EmptyState />
                : sortedProviders.map((provider) => (
                    <ProviderCard
                      key={provider.id}
                      provider={provider}
                      isActive={
                        selectedProvider?.id === provider.id ||
                        activeMapPin === provider.id
                      }
                      onClick={handleProviderClick}
                    />
                  ))
              }

              {/* Pagination */}
              {hasResults && totalPages > 1 && (
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={handlePageChange}
                />
              )}
            </div>
          )}

          {/* Map column */}
          {viewMode !== 'list' && (
            <div style={viewMode === 'split' ? s.mapCol : { height: 'calc(100vh - 200px)', minHeight: '500px' }}>
              <PrimaryMap
                providers={isLoading ? [] : searchResultState.providers}
                activePin={activeMapPin || selectedProvider?.id}
                onPinClick={handleMapPinClick}
                onPinHover={setActiveMapPin}
              />
            </div>
          )}
        </div>
      </div>

      {/* Detail drawer */}
      {selectedProvider && (
        <DetailFeature
          provider={selectedProvider}
          onClose={handleDetailClose}
        />
      )}
    </>
  );
};

// ─── Pagination ────────────────────────────────────────────────────────────
const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1);

  return (
    <nav style={s.pagination} aria-label="Results pagination">
      <button
        style={{
          ...s.pageBtn,
          ...(currentPage === 1 ? s.pageBtnDisabled : {}),
        }}
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        aria-label="Previous page"
      >
        ‹
      </button>

      {pages.map((page) => (
        <button
          key={page}
          style={{
            ...s.pageBtn,
            ...(page === currentPage ? s.pageBtnActive : {}),
          }}
          onClick={() => onPageChange(page)}
          aria-label={`Page ${page}`}
          aria-current={page === currentPage ? 'page' : undefined}
        >
          {page}
        </button>
      ))}

      <button
        style={{
          ...s.pageBtn,
          ...(currentPage === totalPages ? s.pageBtnDisabled : {}),
        }}
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        aria-label="Next page"
      >
        ›
      </button>
    </nav>
  );
};

// ─── Empty state ──────────────────────────────────────────────────────────
const EmptyState = () => (
  <div style={s.emptyState}>
    <div style={s.emptyIcon}>🔍</div>
    <h3 style={s.emptyTitle}>No providers found</h3>
    <p style={s.emptyText}>
      Try expanding your search radius, changing your filters, or searching in a different location.
    </p>
  </div>
);

// ─── Quick link button ─────────────────────────────────────────────────────
const QuickLinkBtn = ({ label, onClick }) => {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      style={{
        ...s.quickLink,
        ...(hovered ? { borderColor: theme.colors.bupaBlue, color: theme.colors.bupaBlue, background: theme.colors.bupaLightBlue } : {}),
      }}
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {label}
    </button>
  );
};

// ─── Icons ─────────────────────────────────────────────────────────────────
const ListIcon = ({ active }) => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <rect x="0" y="1" width="14" height="2" rx="1" fill={active ? 'white' : theme.colors.gray500} />
    <rect x="0" y="6" width="14" height="2" rx="1" fill={active ? 'white' : theme.colors.gray500} />
    <rect x="0" y="11" width="14" height="2" rx="1" fill={active ? 'white' : theme.colors.gray500} />
  </svg>
);

const SplitIcon = ({ active }) => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <rect x="0" y="0" width="6" height="14" rx="1" fill={active ? 'white' : theme.colors.gray500} />
    <rect x="8" y="0" width="6" height="14" rx="1" fill={active ? 'white' : theme.colors.gray500} />
  </svg>
);

const MapToggleIcon = ({ active }) => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M7 1C4.79 1 3 2.79 3 5c0 3.25 4 8 4 8s4-4.75 4-8c0-2.21-1.79-4-4-4zm0 5.5A1.5 1.5 0 115.5 5 1.5 1.5 0 017 6.5z" fill={active ? 'white' : theme.colors.gray500} />
  </svg>
);

export default SearchResultFeature;
