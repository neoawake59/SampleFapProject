// SearchFeature - search form with provider type, location, and filters
// Mirrors: src/packages/features/search/src/index.jsx

import React, { useState, useRef, useCallback } from 'react';
import { useAppState } from '../../../state/src/index';
import { PrimaryInput, PrimarySelect, FilterCheckbox } from '../../../common/ui/src/index';
import { theme, providerTypes, distanceOptions, genderOptions, languageOptions, analyticsEvents } from '../../../common/constants/src/index';
import { analytics } from '../../../common/utilities/src/index';
import { useSticky } from '../../../common/hooks/src/index';

const s = {
  wrapper: {
    background: theme.colors.white,
    borderBottom: `1px solid ${theme.colors.gray200}`,
    position: 'sticky',
    top: 0,
    zIndex: 100,
    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
  },
  inner: {
    maxWidth: '1280px',
    margin: '0 auto',
    padding: '0 24px',
  },
  searchBar: {
    display: 'flex',
    alignItems: 'flex-end',
    gap: '12px',
    padding: '20px 0 0',
    flexWrap: 'wrap',
  },
  fieldWrap: {
    flex: '1 1 220px',
    minWidth: '180px',
  },
  searchBtn: {
    height: '48px',
    padding: '0 28px',
    background: theme.colors.bupaBlue,
    color: theme.colors.white,
    borderRadius: theme.radii.md,
    fontSize: theme.typography.sizes.base,
    fontWeight: theme.typography.weights.semibold,
    border: 'none',
    cursor: 'pointer',
    transition: theme.transitions.fast,
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    whiteSpace: 'nowrap',
    flexShrink: 0,
    minWidth: '130px',
    justifyContent: 'center',
  },
  locationBtn: {
    height: '48px',
    padding: '0 14px',
    background: theme.colors.white,
    color: theme.colors.bupaBlue,
    borderRadius: theme.radii.md,
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.medium,
    border: `1.5px solid ${theme.colors.bupaBlue}`,
    cursor: 'pointer',
    transition: theme.transitions.fast,
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  filterBar: {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    padding: '14px 0',
    flexWrap: 'wrap',
    borderTop: `1px solid ${theme.colors.gray100}`,
    marginTop: '12px',
  },
  filterLabel: {
    fontSize: theme.typography.sizes.sm,
    fontWeight: theme.typography.weights.semibold,
    color: theme.colors.gray600,
    flexShrink: 0,
  },
  filterGroup: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    flexWrap: 'wrap',
  },
  filterSelectWrap: {
    minWidth: '140px',
  },
  divider: {
    width: '1px',
    height: '20px',
    background: theme.colors.gray200,
    flexShrink: 0,
  },
  clearBtn: {
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.bupaBlue,
    fontWeight: theme.typography.weights.medium,
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '4px 8px',
    borderRadius: theme.radii.base,
    marginLeft: 'auto',
    textDecoration: 'underline',
    textUnderlineOffset: '2px',
  },
  resultSummary: {
    padding: '10px 0 14px',
    fontSize: theme.typography.sizes.sm,
    color: theme.colors.gray500,
    borderTop: `1px solid ${theme.colors.gray100}`,
  },
  loadingDot: {
    display: 'inline-block',
    width: '6px',
    height: '6px',
    borderRadius: '50%',
    background: theme.colors.bupaBlue,
    animation: 'pulse 1s infinite',
    marginLeft: '6px',
  },
};

const SearchFeature = () => {
  const {
    searchState,
    searchResultState,
    userLocationState,
    dispatchSearch,
    performSearch,
    requestUserLocation,
  } = useAppState();

  const [locationHovered, setLocationHovered] = useState(false);
  const [searchBtnHovered, setSearchBtnHovered] = useState(false);
  const locationInputRef = useRef(null);

  const handleProviderTypeChange = (e) => {
    dispatchSearch({ type: 'SEARCH_UPDATE_VALUES', payload: { providerType: e.target.value } });
  };

  const handleLocationChange = (e) => {
    dispatchSearch({ type: 'SEARCH_UPDATE_VALUES', payload: { location: e.target.value } });
  };

  const handleFilterChange = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    dispatchSearch({ type: 'SEARCH_UPDATE_FILTERS', payload: { [key]: value } });
    analytics.track(analyticsEvents.FILTER_APPLIED, { filter: key, value });
  };

  const handleSearch = useCallback(() => {
    analytics.track(analyticsEvents.SEARCH_SUBMITTED, {
      providerType: searchState.providerType,
      location: searchState.location,
    });
    performSearch();
  }, [searchState, performSearch]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSearch();
  };

  const handleClearFilters = () => {
    dispatchSearch({ type: 'SEARCH_RESET' });
  };

  const handleUseMyLocation = async () => {
    await requestUserLocation();
    if (locationInputRef.current) locationInputRef.current.focus();
  };

  const isLocating = userLocationState.status === 'requesting';

  const hasActiveFilters =
    searchState.filters.gender ||
    searchState.filters.language ||
    searchState.filters.openNow ||
    searchState.filters.acceptingNewPatients ||
    searchState.filters.distance !== 5;

  const resultCountText = () => {
    if (searchResultState.isLoading) return null;
    if (!searchState.hasSearched) return null;
    const count = searchResultState.totalCount;
    const type = searchState.providerType
      ? providerTypes.find((t) => t.value === searchState.providerType)?.label || 'providers'
      : 'providers';
    const loc = searchState.location ? ` near ${searchState.location}` : '';
    if (count === 0) return `No ${type} found${loc}.`;
    return `Showing ${count} ${count === 1 ? 'provider' : 'providers'}${loc}`;
  };

  return (
    <div style={s.wrapper} role="search" aria-label="Find a provider search">
      <div style={s.inner}>
        {/* Main search bar */}
        <div style={s.searchBar}>
          {/* Provider type */}
          <div style={s.fieldWrap}>
            <PrimarySelect
              id="provider-type"
              label="What are you looking for?"
              value={searchState.providerType}
              onChange={handleProviderTypeChange}
              options={providerTypes}
            />
          </div>

          {/* Location */}
          <div style={{ ...s.fieldWrap, position: 'relative' }}>
            <PrimaryInput
              ref={locationInputRef}
              id="location"
              label="Where?"
              placeholder="Suburb or postcode"
              value={searchState.location}
              onChange={handleLocationChange}
              onKeyDown={handleKeyDown}
              iconLeft={<LocationIcon />}
              autoComplete="off"
            />
          </div>

          {/* Use my location */}
          <button
            style={{
              ...s.locationBtn,
              ...(locationHovered ? { background: theme.colors.bupaLightBlue } : {}),
              ...(isLocating ? { opacity: 0.7, cursor: 'wait' } : {}),
            }}
            onClick={handleUseMyLocation}
            onMouseEnter={() => setLocationHovered(true)}
            onMouseLeave={() => setLocationHovered(false)}
            disabled={isLocating}
            aria-label="Use my current location"
            title="Use my current location"
          >
            <GpsIcon />
            {isLocating ? 'Locating...' : 'Use my location'}
          </button>

          {/* Search button */}
          <button
            style={{
              ...s.searchBtn,
              ...(searchBtnHovered ? { background: '#0099D4' } : {}),
              ...(searchResultState.isLoading ? { opacity: 0.8, cursor: 'wait' } : {}),
            }}
            onClick={handleSearch}
            onMouseEnter={() => setSearchBtnHovered(true)}
            onMouseLeave={() => setSearchBtnHovered(false)}
            disabled={searchResultState.isLoading}
            aria-label="Search for providers"
          >
            <SearchIcon />
            {searchResultState.isLoading ? 'Searching...' : 'Search'}
          </button>
        </div>

        {/* Filter bar */}
        <div style={s.filterBar} aria-label="Search filters">
          <span style={s.filterLabel}>Filter by:</span>

          <div style={s.filterGroup}>
            <div style={s.filterSelectWrap}>
              <PrimarySelect
                id="filter-distance"
                value={searchState.filters.distance}
                onChange={(e) => dispatchSearch({
                  type: 'SEARCH_UPDATE_FILTERS',
                  payload: { distance: Number(e.target.value) },
                })}
                options={distanceOptions}
              />
            </div>

            <div style={s.filterSelectWrap}>
              <PrimarySelect
                id="filter-gender"
                value={searchState.filters.gender}
                onChange={handleFilterChange('gender')}
                options={genderOptions}
              />
            </div>

            <div style={s.filterSelectWrap}>
              <PrimarySelect
                id="filter-language"
                value={searchState.filters.language}
                onChange={handleFilterChange('language')}
                options={languageOptions}
              />
            </div>
          </div>

          <div style={s.divider} aria-hidden="true" />

          <div style={s.filterGroup}>
            <FilterCheckbox
              id="filter-open-now"
              label="Open now"
              checked={searchState.filters.openNow}
              onChange={handleFilterChange('openNow')}
            />
            <FilterCheckbox
              id="filter-accepting"
              label="Accepting new patients"
              checked={searchState.filters.acceptingNewPatients}
              onChange={handleFilterChange('acceptingNewPatients')}
            />
          </div>

          {hasActiveFilters && (
            <button style={s.clearBtn} onClick={handleClearFilters}>
              Clear filters
            </button>
          )}
        </div>

        {/* Result count */}
        {resultCountText() && (
          <div style={s.resultSummary} aria-live="polite">
            {resultCountText()}
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Icons ─────────────────────────────────────────────────────────────────
const SearchIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <circle cx="6.5" cy="6.5" r="5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M10.5 10.5L14 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const LocationIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <path d="M8 1C5.24 1 3 3.24 3 6c0 3.75 5 9 5 9s5-5.25 5-9c0-2.76-2.24-5-5-5zm0 6.75A1.75 1.75 0 116 6a1.75 1.75 0 012 1.75z" fill="currentColor" />
  </svg>
);

const GpsIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <circle cx="7" cy="7" r="2.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M7 1v2M7 11v2M1 7h2M11 7h2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export default SearchFeature;
