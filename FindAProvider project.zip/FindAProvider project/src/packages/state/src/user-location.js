// UserLocationState - manages geolocation data and status
// Mirrors: src/packages/state/src/user-location.js

export const initialUserLocationState = {
  coordinates: null,
  suburb: '',
  postcode: '',
  state: '',
  status: 'idle',  // 'idle' | 'requesting' | 'granted' | 'denied' | 'error'
  error: null,
};

export const userLocationReducer = (state, action) => {
  switch (action.type) {
    case 'USER_LOCATION_REQUESTING':
      return { ...state, status: 'requesting', error: null };

    case 'USER_LOCATION_SUCCESS':
      return {
        ...state,
        status: 'granted',
        coordinates: action.payload.coordinates,
        suburb: action.payload.suburb || '',
        postcode: action.payload.postcode || '',
        state: action.payload.state || '',
        error: null,
      };

    case 'USER_LOCATION_DENIED':
      return { ...state, status: 'denied', error: 'Location access was denied.' };

    case 'USER_LOCATION_ERROR':
      return { ...state, status: 'error', error: action.payload };

    case 'USER_LOCATION_RESET':
      return { ...initialUserLocationState };

    default:
      return state;
  }
};
