// SearchState - manages the search form values and filter state
// Mirrors: src/packages/state/src/search.js

export const initialSearchState = {
  providerType: '',
  location: '',
  suburb: '',
  postcode: '',
  coordinates: null,
  filters: {
    distance: 5,
    gender: '',
    language: '',
    openNow: false,
    acceptingNewPatients: false,
  },
  hasSearched: false,
  isSearching: false,
};

export const searchReducer = (state, action) => {
  switch (action.type) {
    case 'SEARCH_UPDATE_VALUES':
      return { ...state, ...action.payload };

    case 'SEARCH_UPDATE_FILTERS':
      return {
        ...state,
        filters: { ...state.filters, ...action.payload },
      };

    case 'SEARCH_SET_SEARCHING':
      return { ...state, isSearching: action.payload };

    case 'SEARCH_SUBMITTED':
      return { ...state, hasSearched: true, isSearching: false };

    case 'SEARCH_RESET':
      return { ...initialSearchState };

    case 'SEARCH_HYDRATE_FROM_URL':
      return {
        ...state,
        providerType: action.payload.q || '',
        location:     action.payload.location || '',
        filters: {
          ...state.filters,
          distance:            Number(action.payload.distance) || 5,
          gender:              action.payload.gender || '',
          language:            action.payload.language || '',
          openNow:             action.payload.openNow === 'true',
          acceptingNewPatients:action.payload.accepting === 'true',
        },
        hasSearched: !!(action.payload.q || action.payload.location),
      };

    default:
      return state;
  }
};
