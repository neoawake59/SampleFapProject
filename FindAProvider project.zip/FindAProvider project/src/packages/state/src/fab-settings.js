// FabSettingsState - hydrates config/settings from server-rendered attributes
// Mirrors: src/packages/state/src/fab-settings.js

export const initialFabSettingsState = {
  apiEndpoints: {
    search: '/api/find-a-provider/search',
    detail: '/api/find-a-provider/detail',
    geolocation: '/api/geolocation/reverse',
  },
  featureFlags: {
    showMap: true,
    showRatings: true,
    enableGeolocation: true,
    showBulkBilling: true,
  },
  defaults: {
    searchRadius: 5,
    resultsPerPage: 6,
    defaultView: 'split',   // 'list' | 'map' | 'split'
  },
  content: {
    searchPlaceholder: 'e.g. suburb or postcode',
    noResultsMessage: 'No providers found matching your search. Try expanding your search area or changing your filters.',
    mapUnavailableMessage: 'Map view is temporarily unavailable.',
  },
};

export const fabSettingsReducer = (state, action) => {
  switch (action.type) {
    case 'FAB_SETTINGS_HYDRATE':
      return { ...state, ...action.payload };
    default:
      return state;
  }
};
