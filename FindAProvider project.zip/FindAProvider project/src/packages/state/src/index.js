// StatePackage - combines all state domains into a single React Context
// Simulates @/find-and-book-fe.state / @/valhalla.state domains
// Mirrors: src/packages/state/src/index.js

import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { searchReducer, initialSearchState } from './search';
import {
  searchResultReducer,
  initialSearchResultState,
  selectPagedProviders,
  selectTotalPages,
} from './search-result';
import { userLocationReducer, initialUserLocationState } from './user-location';
import { urlReducer, initialUrlState, syncSearchToUrl } from './url';
import { fabSettingsReducer, initialFabSettingsState } from './fab-settings';
import { filterProviders, geolocation } from '../../common/utilities/src/index';

// ─── Context ─────────────────────────────────────────────────────────────
const StateContext = createContext(null);

// ─── Provider ─────────────────────────────────────────────────────────────
export const StateProvider = ({ children }) => {
  const [searchState, dispatchSearch]           = useReducer(searchReducer, initialSearchState);
  const [searchResultState, dispatchSearchResult] = useReducer(searchResultReducer, initialSearchResultState);
  const [userLocationState, dispatchUserLocation] = useReducer(userLocationReducer, initialUserLocationState);
  const [urlState, dispatchUrl]                 = useReducer(urlReducer, initialUrlState);
  const [fabSettingsState]                      = useReducer(fabSettingsReducer, initialFabSettingsState);

  // Hydrate from URL on mount
  useEffect(() => {
    dispatchUrl({ type: 'URL_HYDRATE' });
    const params = Object.fromEntries(new URLSearchParams(window.location.search));
    if (Object.keys(params).length > 0) {
      dispatchSearch({ type: 'SEARCH_HYDRATE_FROM_URL', payload: params });
    }
  }, []);

  // ─── Search action ────────────────────────────────────────────────────
  const performSearch = (overrides = {}) => {
    const state = { ...searchState, ...overrides };
    dispatchSearchResult({ type: 'RESULTS_SET_LOADING', payload: true });
    dispatchSearch({ type: 'SEARCH_SUBMITTED' });

    // Simulate async search with mock data
    setTimeout(() => {
      const filtered = filterProviders(
        searchResultState.allProviders,
        {
          providerType: state.providerType,
          ...state.filters,
        }
      );
      dispatchSearchResult({ type: 'RESULTS_HYDRATE', payload: filtered });
      syncSearchToUrl(state);
    }, 600);
  };

  // ─── Geolocation action ───────────────────────────────────────────────
  const requestUserLocation = async () => {
    dispatchUserLocation({ type: 'USER_LOCATION_REQUESTING' });
    try {
      const coords = await geolocation.getCurrentPosition();
      const geo = await geolocation.reverseGeocode(coords.lat, coords.lng);
      dispatchUserLocation({
        type: 'USER_LOCATION_SUCCESS',
        payload: { coordinates: coords, ...geo },
      });
      dispatchSearch({
        type: 'SEARCH_UPDATE_VALUES',
        payload: { location: `${geo.suburb} ${geo.postcode}`, suburb: geo.suburb, postcode: geo.postcode },
      });
    } catch (err) {
      if (err.code === 1) {
        dispatchUserLocation({ type: 'USER_LOCATION_DENIED' });
      } else {
        dispatchUserLocation({ type: 'USER_LOCATION_ERROR', payload: err.message });
      }
    }
  };

  const value = {
    // State domains
    searchState,
    searchResultState,
    userLocationState,
    urlState,
    fabSettingsState,

    // Dispatchers
    dispatchSearch,
    dispatchSearchResult,
    dispatchUserLocation,

    // Selectors
    pagedProviders: selectPagedProviders(searchResultState),
    totalPages: selectTotalPages(searchResultState),

    // Actions
    performSearch,
    requestUserLocation,
  };

  return <StateContext.Provider value={value}>{children}</StateContext.Provider>;
};

// ─── Consumer hook ────────────────────────────────────────────────────────
export const useAppState = () => {
  const ctx = useContext(StateContext);
  if (!ctx) throw new Error('useAppState must be used within StateProvider');
  return ctx;
};
