// UrlState - keeps browser URL query string in sync with app state
// Mirrors: src/packages/state/src/url.js

import { urlHelper } from '../../common/utilities/src/index';
import { urlParams } from '../../common/constants/src/index';

export const initialUrlState = {
  params: {},
};

export const urlReducer = (state, action) => {
  switch (action.type) {
    case 'URL_HYDRATE': {
      const search = window.location.search;
      const params = Object.fromEntries(new URLSearchParams(search));
      return { ...state, params };
    }
    case 'URL_UPDATE':
      return { ...state, params: { ...state.params, ...action.payload } };
    case 'URL_CLEAR':
      return { ...initialUrlState };
    default:
      return state;
  }
};

// Sync search state to URL
export const syncSearchToUrl = (searchState) => {
  urlHelper.setParams({
    [urlParams.QUERY]:    searchState.providerType || null,
    [urlParams.LOCATION]: searchState.location || null,
    [urlParams.DISTANCE]: searchState.filters.distance !== 5 ? searchState.filters.distance : null,
    [urlParams.GENDER]:   searchState.filters.gender || null,
    [urlParams.LANGUAGE]: searchState.filters.language || null,
    [urlParams.OPEN_NOW]: searchState.filters.openNow ? 'true' : null,
    [urlParams.ACCEPTING]:searchState.filters.acceptingNewPatients ? 'true' : null,
  });
};
