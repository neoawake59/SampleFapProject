// SearchResultState - manages provider results, pagination, and selected provider
// Mirrors: src/packages/state/src/search-result.js

import { MOCK_PROVIDERS } from './mock-data';
import { PAGE_SIZE } from '../../common/constants/src/index';

export const initialSearchResultState = {
  providers: [],
  allProviders: MOCK_PROVIDERS,
  selectedProvider: null,
  totalCount: 0,
  currentPage: 1,
  viewMode: 'split',  // 'list' | 'map' | 'split'
  isLoading: false,
  hasResults: false,
  activeMapPin: null,
};

export const searchResultReducer = (state, action) => {
  switch (action.type) {
    case 'RESULTS_HYDRATE': {
      const providers = action.payload;
      return {
        ...state,
        providers,
        totalCount: providers.length,
        currentPage: 1,
        hasResults: providers.length > 0,
        isLoading: false,
      };
    }

    case 'RESULTS_SET_LOADING':
      return { ...state, isLoading: action.payload };

    case 'RESULTS_SET_PAGE':
      return { ...state, currentPage: action.payload };

    case 'RESULTS_SET_VIEW_MODE':
      return { ...state, viewMode: action.payload };

    case 'RESULTS_SELECT_PROVIDER':
      return { ...state, selectedProvider: action.payload };

    case 'RESULTS_DESELECT_PROVIDER':
      return { ...state, selectedProvider: null };

    case 'RESULTS_SET_ACTIVE_MAP_PIN':
      return { ...state, activeMapPin: action.payload };

    case 'RESULTS_RESET':
      return { ...initialSearchResultState, allProviders: state.allProviders };

    default:
      return state;
  }
};

// Selector: returns paginated slice of current results
export const selectPagedProviders = (state) => {
  const start = (state.currentPage - 1) * PAGE_SIZE;
  return state.providers.slice(start, start + PAGE_SIZE);
};

export const selectTotalPages = (state) => Math.ceil(state.totalCount / PAGE_SIZE);
