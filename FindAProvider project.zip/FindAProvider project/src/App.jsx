// App - root composition layer
// Wires StateProvider around all feature components (loaded via bundle entry)
// Mirrors the CMS-driven page composition described in the architecture

import React from 'react';
import { StateProvider } from './packages/state/src/index';
import {
  PageTitleFeature,
  SearchFeature,
  SearchResultFeature,
} from './packages/pages/bundle/src/index';
import { theme } from './packages/common/constants/src/index';

// ─── Site Header ──────────────────────────────────────────────────────────
const SiteHeader = () => (
  <header
    style={{
      background: theme.colors.bupaNavy,
      height: '64px',
      display: 'flex',
      alignItems: 'center',
      padding: '0 24px',
      position: 'sticky',
      top: 0,
      zIndex: 200,
      boxShadow: '0 2px 8px rgba(0,0,0,0.25)',
    }}
  >
    <div
      style={{
        maxWidth: '1280px',
        width: '100%',
        margin: '0 auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}
    >
      {/* Bupa Logo wordmark */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <BupaLogo />
      </div>

      {/* Nav links */}
      <nav style={{ display: 'flex', gap: '28px', alignItems: 'center' }}>
        {['Health Insurance', 'Find a Provider', 'Extras', 'Contact'].map((item, i) => (
          <a
            key={item}
            href="/"
            style={{
              fontSize: theme.typography.sizes.sm,
              fontWeight: i === 1 ? theme.typography.weights.semibold : theme.typography.weights.regular,
              color: i === 1 ? theme.colors.bupaBlue : 'rgba(255,255,255,0.8)',
              textDecoration: 'none',
              transition: theme.transitions.fast,
              borderBottom: i === 1 ? `2px solid ${theme.colors.bupaBlue}` : '2px solid transparent',
              paddingBottom: '2px',
            }}
            aria-current={i === 1 ? 'page' : undefined}
          >
            {item}
          </a>
        ))}

        <button
          style={{
            padding: '8px 18px',
            background: theme.colors.bupaBlue,
            color: theme.colors.white,
            borderRadius: theme.radii.full,
            fontSize: theme.typography.sizes.sm,
            fontWeight: theme.typography.weights.semibold,
            border: 'none',
            cursor: 'pointer',
          }}
        >
          Log in
        </button>
      </nav>
    </div>
  </header>
);

// ─── Site Footer ──────────────────────────────────────────────────────────
const SiteFooter = () => (
  <footer
    style={{
      background: theme.colors.bupaNavy,
      color: 'rgba(255,255,255,0.65)',
      padding: '40px 24px',
      marginTop: 'auto',
    }}
  >
    <div
      style={{
        maxWidth: '1280px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
        gap: '32px',
        marginBottom: '32px',
      }}
    >
      {[
        {
          heading: 'Find a Provider',
          links: ['Search for a GP', 'Find a Specialist', 'Dental providers', 'Allied Health'],
        },
        {
          heading: 'Health Insurance',
          links: ['Hospital cover', 'Extras cover', 'Combined cover', 'Overseas visitors'],
        },
        {
          heading: 'Support',
          links: ['Contact us', 'FAQs', 'Claims', 'Make a complaint'],
        },
        {
          heading: 'About Bupa',
          links: ['Who we are', 'Careers', 'News', 'Accessibility'],
        },
      ].map((col) => (
        <div key={col.heading}>
          <div style={{
            fontSize: theme.typography.sizes.sm,
            fontWeight: theme.typography.weights.bold,
            color: theme.colors.white,
            marginBottom: '12px',
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
          }}>
            {col.heading}
          </div>
          {col.links.map((link) => (
            <div key={link} style={{ marginBottom: '8px' }}>
              <a
                href="/"
                style={{
                  fontSize: theme.typography.sizes.sm,
                  color: 'rgba(255,255,255,0.65)',
                  textDecoration: 'none',
                }}
              >
                {link}
              </a>
            </div>
          ))}
        </div>
      ))}
    </div>

    <div style={{
      borderTop: '1px solid rgba(255,255,255,0.12)',
      paddingTop: '24px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      flexWrap: 'wrap',
      gap: '12px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <BupaLogo small />
        <span style={{ fontSize: theme.typography.sizes.xs }}>
          © {new Date().getFullYear()} Bupa Australia Pty Ltd. ABN 81 000 057 590.
        </span>
      </div>
      <div style={{ display: 'flex', gap: '16px', fontSize: theme.typography.sizes.xs }}>
        {['Privacy Policy', 'Terms of Use', 'Accessibility'].map((item) => (
          <a key={item} href="/" style={{ color: 'rgba(255,255,255,0.55)', textDecoration: 'none' }}>
            {item}
          </a>
        ))}
      </div>
    </div>
  </footer>
);

// ─── Bupa SVG Logo ─────────────────────────────────────────────────────────
const BupaLogo = ({ small }) => (
  <svg
    width={small ? 48 : 64}
    height={small ? 18 : 24}
    viewBox="0 0 64 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-label="Bupa"
    role="img"
  >
    {/* Stylised BUPA wordmark — simplified representation */}
    <text
      x="0"
      y="20"
      fontFamily="'Inter', Arial, sans-serif"
      fontWeight="800"
      fontSize={small ? "16" : "20"}
      fill={theme.colors.bupaBlue}
      letterSpacing="-0.5"
    >
      bupa
    </text>
  </svg>
);

// ─── Page layout ───────────────────────────────────────────────────────────
const App = () => (
  <StateProvider>
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Global site header */}
      <SiteHeader />

      {/* Main page content */}
      <main style={{ flex: 1 }}>
        {/* find-and-book.page-title */}
        <PageTitleFeature />

        {/* find-and-book.search */}
        <SearchFeature />

        {/* find-and-book.search-result */}
        <SearchResultFeature />
      </main>

      {/* Site footer */}
      <SiteFooter />
    </div>
  </StateProvider>
);

export default App;
